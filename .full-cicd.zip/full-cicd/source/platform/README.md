


### Deploy everything

```
az deployment group create --resource-group 'trojan-resources'  --template-file .\platform.bicep
```